 function(e) {
                function t(e, t, n, i) {
                    var o, r, a, s, c, l, f, p = t && t.ownerDocument,
                        h = t ? t.nodeType : 9;
                    if (n = n || [], "string" != typeof e || !e || 1 !== h && 9 !== h && 11 !== h) return n;
                    if (!i && ((t ? t.ownerDocument || t : R) !== I && A(t), t = t || I, D)) {
                        if (11 !== h && (c = me.exec(e)))
                            if (o = c[1]) {
                                if (9 === h) {
                                    if (!(a = t.getElementById(o))) return n;
                                    if (a.id === o) return n.push(a), n
                                } else if (p && (a = p.getElementById(o)) && P(t, a) && a.id === o) return n.push(a), n
                            } else {
                                if (c[2]) return X.apply(n, t.getElementsByTagName(e)), n;
                                if ((o = c[3]) && w.getElementsByClassName && t.getElementsByClassName) return X.apply(n, t.getElementsByClassName(o)), n
                            }
                        if (w.qsa && !B[e + " "] && (!M || !M.test(e))) {
                            if (1 !== h) p = t, f = e;
                            else if ("object" !== t.nodeName.toLowerCase()) {
                                for ((s = t.getAttribute("id")) ? s = s.replace(be, we) : t.setAttribute("id", s = F), l = j(e), r = l.length; r--;) l[r] = "#" + s + " " + d(l[r]);
                                f = l.join(","), p = ve.test(e) && u(t.parentNode) || t
                            }
                            if (f) try {
                                return X.apply(n, p.querySelectorAll(f)), n
                            } catch (e) {} finally {
                                s === F && t.removeAttribute("id")
                            }
                        }
                    }
                    return E(e.replace(re, "$1"), t, n, i)
                }

                function n() {
                    function e(n, i) {
                        return t.push(n + " ") > _.cacheLength && delete e[t.shift()], e[n + " "] = i
                    }
                    var t = [];
                    return e
                }

                function i(e) {
                    return e[F] = !0, e
                }

                function o(e) {
                    var t = I.createElement("fieldset");
                    try {
                        return !!e(t)
                    } catch (e) {
                        return !1
                    } finally {
                        t.parentNode && t.parentNode.removeChild(t), t = null
                    }
                }

                function r(e, t) {
                    for (var n = e.split("|"), i = n.length; i--;) _.attrHandle[n[i]] = t
                }

                function a(e, t) {
                    var n = t && e,
                        i = n && 1 === e.nodeType && 1 === t.nodeType && e.sourceIndex - t.sourceIndex;
                    if (i) return i;
                    if (n)
                        for (; n = n.nextSibling;)
                            if (n === t) return -1;
                    return e ? 1 : -1
                }

                function s(e) {
                    return function(t) {
                        return "form" in t ? t.parentNode && !1 === t.disabled ? "label" in t ? "label" in t.parentNode ? t.parentNode.disabled === e : t.disabled === e : t.isDisabled === e || t.isDisabled !== !e && xe(t) === e : t.disabled === e : "label" in t && t.disabled === e
                    }
                }

                function c(e) {
                    return i(function(t) {
                        return t = +t, i(function(n, i) {
                            for (var o, r = e([], n.length, t), a = r.length; a--;) n[o = r[a]] && (n[o] = !(i[o] = n[o]))
                        })
                    })
                }

                function u(e) {
                    return e && void 0 !== e.getElementsByTagName && e
                }

                function l() {}

                function d(e) {
                    for (var t = 0, n = e.length, i = ""; t < n; t++) i += e[t].value;
                    return i
                }

                function f(e, t, n) {
                    var i = t.dir,
                        o = t.next,
                        r = o || i,
                        a = n && "parentNode" === r,
                        s = U++;
                    return t.first ? function(t, n, o) {
                        for (; t = t[i];)
                            if (1 === t.nodeType || a) return e(t, n, o);
                        return !1
                    } : function(t, n, c) {
                        var u, l, d, f = [q, s];
                        if (c) {
                            for (; t = t[i];)
                                if ((1 === t.nodeType || a) && e(t, n, c)) return !0
                        } else
                            for (; t = t[i];)
                                if (1 === t.nodeType || a)
                                    if (d = t[F] || (t[F] = {}), l = d[t.uniqueID] || (d[t.uniqueID] = {}), o && o === t.nodeName.toLowerCase()) t = t[i] || t;
                                    else {
                                        if ((u = l[r]) && u[0] === q && u[1] === s) return f[2] = u[2];
                                        if (l[r] = f, f[2] = e(t, n, c)) return !0
                                    } return !1
                    }
                }

                function p(e) {
                    return e.length > 1 ? function(t, n, i) {
                        for (var o = e.length; o--;)
                            if (!e[o](t, n, i)) return !1;
                        return !0
                    } : e[0]
                }

                function h(e, n, i) {
                    for (var o = 0, r = n.length; o < r; o++) t(e, n[o], i);
                    return i
                }

                function m(e, t, n, i, o) {
                    for (var r, a = [], s = 0, c = e.length, u = null != t; s < c; s++)(r = e[s]) && (n && !n(r, i, o) || (a.push(r), u && t.push(s)));
                    return a
                }

                function v(e, t, n, o, r, a) {
                    return o && !o[F] && (o = v(o)), r && !r[F] && (r = v(r, a)), i(function(i, a, s, c) {
                        var u, l, d, f = [],
                            p = [],
                            v = a.length,
                            g = i || h(t || "*", s.nodeType ? [s] : s, []),
                            y = !e || !i && t ? g : m(g, f, e, s, c),
                            b = n ? r || (i ? e : v || o) ? [] : a : y;
                        if (n && n(y, b, s, c), o)
                            for (u = m(b, p), o(u, [], s, c), l = u.length; l--;)(d = u[l]) && (b[p[l]] = !(y[p[l]] = d));
                        if (i) {
                            if (r || e) {
                                if (r) {
                                    for (u = [], l = b.length; l--;)(d = b[l]) && u.push(y[l] = d);
                                    r(null, b = [], u, c)
                                }
                                for (l = b.length; l--;)(d = b[l]) && (u = r ? Q(i, d) : f[l]) > -1 && (i[u] = !(a[u] = d))
                            }
                        } else b = m(b === a ? b.splice(v, b.length) : b), r ? r(null, a, b, c) : X.apply(a, b)
                    })
                }

                function g(e) {
                    for (var t, n, i, o = e.length, r = _.relative[e[0].type], a = r || _.relative[" "], s = r ? 1 : 0, c = f(function(e) {
                            return e === t
                        }, a, !0), u = f(function(e) {
                            return Q(t, e) > -1
                        }, a, !0), l = [function(e, n, i) {
                            var o = !r && (i || n !== N) || ((t = n).nodeType ? c(e, n, i) : u(e, n, i));
                            return t = null, o
                        }]; s < o; s++)
                        if (n = _.relative[e[s].type]) l = [f(p(l), n)];
                        else {
                            if (n = _.filter[e[s].type].apply(null, e[s].matches), n[F]) {
                                for (i = ++s; i < o && !_.relative[e[i].type]; i++);
                                return v(s > 1 && p(l), s > 1 && d(e.slice(0, s - 1).concat({
                                    value: " " === e[s - 2].type ? "*" : ""
                                })).replace(re, "$1"), n, s < i && g(e.slice(s, i)), i < o && g(e = e.slice(i)), i < o && d(e))
                            }
                            l.push(n)
                        }
                    return p(l)
                }

                function y(e, n) {
                    var o = n.length > 0,
                        r = e.length > 0,
                        a = function(i, a, s, c, u) {
                            var l, d, f, p = 0,
                                h = "0",
                                v = i && [],
                                g = [],
                                y = N,
                                b = i || r && _.find.TAG("*", u),
                                w = q += null == y ? 1 : Math.random() || .1,
                                x = b.length;
                            for (u && (N = a === I || a || u); h !== x && null != (l = b[h]); h++) {
                                if (r && l) {
                                    for (d = 0, a || l.ownerDocument === I || (A(l), s = !D); f = e[d++];)
                                        if (f(l, a || I, s)) {
                                            c.push(l);
                                            break
                                        }
                                    u && (q = w)
                                }
                                o && ((l = !f && l) && p--, i && v.push(l))
                            }
                            if (p += h, o && h !== p) {
                                for (d = 0; f = n[d++];) f(v, g, a, s);
                                if (i) {
                                    if (p > 0)
                                        for (; h--;) v[h] || g[h] || (g[h] = Y.call(c));
                                    g = m(g)
                                }
                                X.apply(c, g), u && !i && g.length > 0 && p + n.length > 1 && t.uniqueSort(c)
                            }
                            return u && (q = w, N = y), v
                        };
                    return o ? i(a) : a
                }
                var b, w, _, x, k, j, C, E, N, S, T, A, I, O, D, M, $, L, P, F = "sizzle" + 1 * new Date,
                    R = e.document,
                    q = 0,
                    U = 0,
                    H = n(),
                    V = n(),
                    B = n(),
                    z = function(e, t) {
                        return e === t && (T = !0), 0
                    },
                    W = {}.hasOwnProperty,
                    J = [],
                    Y = J.pop,
                    G = J.push,
                    X = J.push,
                    K = J.slice,
                    Q = function(e, t) {
                        for (var n = 0, i = e.length; n < i; n++)
                            if (e[n] === t) return n;
                        return -1
                    },
                    Z = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",
                    ee = "[\\x20\\t\\r\\n\\f]",
                    te = "(?:\\\\.|[\\w-]|[^\0-\\xa0])+",
                    ne = "\\[" + ee + "*(" + te + ")(?:" + ee + "*([*^$|!~]?=)" + ee + "*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|(" + te + "))|)" + ee + "*\\]",
                    ie = ":(" + te + ")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|" + ne + ")*)|.*)\\)|)",
                    oe = new RegExp(ee + "+", "g"),
                    re = new RegExp("^" + ee + "+|((?:^|[^\\\\])(?:\\\\.)*)" + ee + "+$", "g"),
                    ae = new RegExp("^" + ee + "*," + ee + "*"),
                    se = new RegExp("^" + ee + "*([>+~]|" + ee + ")" + ee + "*"),
                    ce = new RegExp("=" + ee + "*([^\\]'\"]*?)" + ee + "*\\]", "g"),
                    ue = new RegExp(ie),
                    le = new RegExp("^" + te + "$"),
                    de = {
                        ID: new RegExp("^#(" + te + ")"),
                        CLASS: new RegExp("^\\.(" + te + ")"),
                        TAG: new RegExp("^(" + te + "|[*])"),
                        ATTR: new RegExp("^" + ne),
                        PSEUDO: new RegExp("^" + ie),
                        CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + ee + "*(even|odd|(([+-]|)(\\d*)n|)" + ee + "*(?:([+-]|)" + ee + "*(\\d+)|))" + ee + "*\\)|)", "i"),
                        bool: new RegExp("^(?:" + Z + ")$", "i"),
                        needsContext: new RegExp("^" + ee + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + ee + "*((?:-\\d)?\\d*)" + ee + "*\\)|)(?=[^-]|$)", "i")
                    },
                    fe = /^(?:input|select|textarea|button)$/i,
                    pe = /^h\d$/i,
                    he = /^[^{]+\{\s*\[native \w/,
                    me = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
                    ve = /[+~]/,
                    ge = new RegExp("\\\\([\\da-f]{1,6}" + ee + "?|(" + ee + ")|.)", "ig"),
                    ye = function(e, t, n) {
                        var i = "0x" + t - 65536;
                        return i !== i || n ? t : i < 0 ? String.fromCharCode(i + 65536) : String.fromCharCode(i >> 10 | 55296, 1023 & i | 56320)
                    },
                    be = /([\0-\x1f\x7f]|^-?\d)|^-$|[^\0-\x1f\x7f-\uFFFF\w-]/g,
                    we = function(e, t) {
                        return t ? "\0" === e ? "ï¿½" : e.slice(0, -1) + "\\" + e.charCodeAt(e.length - 1).toString(16) + " " : "\\" + e
                    },
                    _e = function() {
                        A()
                    },
                    xe = f(function(e) {
                        return !0 === e.disabled && ("form" in e || "label" in e)
                    }, {
                        dir: "parentNode",
                        next: "legend"
                    });
                try {
                    X.apply(J = K.call(R.childNodes), R.childNodes), J[R.childNodes.length].nodeType
                } catch (e) {
                    X = {
                        apply: J.length ? function(e, t) {
                            G.apply(e, K.call(t))
                        } : function(e, t) {
                            for (var n = e.length, i = 0; e[n++] = t[i++];);
                            e.length = n - 1
                        }
                    }
                }
                w = t.support = {}, k = t.isXML = function(e) {
                    var t = e && (e.ownerDocument || e).documentElement;
                    return !!t && "HTML" !== t.nodeName
                }, A = t.setDocument = function(e) {
                    var t, n, i = e ? e.ownerDocument || e : R;
                    return i !== I && 9 === i.nodeType && i.documentElement ? (I = i, O = I.documentElement, D = !k(I), R !== I && (n = I.defaultView) && n.top !== n && (n.addEventListener ? n.addEventListener("unload", _e, !1) : n.attachEvent && n.attachEvent("onunload", _e)), w.attributes = o(function(e) {
                        return e.className = "i", !e.getAttribute("className")
                    }), w.getElementsByTagName = o(function(e) {
                        return e.appendChild(I.createComment("")), !e.getElementsByTagName("*").length
                    }), w.getElementsByClassName = he.test(I.getElementsByClassName), w.getById = o(function(e) {
                        return O.appendChild(e).id = F, !I.getElementsByName || !I.getElementsByName(F).length
                    }), w.getById ? (_.filter.ID = function(e) {
                        var t = e.replace(ge, ye);
                        return function(e) {
                            return e.getAttribute("id") === t
                        }
                    }, _.find.ID = function(e, t) {
                        if (void 0 !== t.getElementById && D) {
                            var n = t.getElementById(e);
                            return n ? [n] : []
                        }
                    }) : (_.filter.ID = function(e) {
                        var t = e.replace(ge, ye);
                        return function(e) {
                            var n = void 0 !== e.getAttributeNode && e.getAttributeNode("id");
                            return n && n.value === t
                        }
                    }, _.find.ID = function(e, t) {
                        if (void 0 !== t.getElementById && D) {
                            var n, i, o, r = t.getElementById(e);
                            if (r) {
                                if ((n = r.getAttributeNode("id")) && n.value === e) return [r];
                                for (o = t.getElementsByName(e), i = 0; r = o[i++];)
                                    if ((n = r.getAttributeNode("id")) && n.value === e) return [r]
                            }
                            return []
                        }
                    }), _.find.TAG = w.getElementsByTagName ? function(e, t) {
                        return void 0 !== t.getElementsByTagName ? t.getElementsByTagName(e) : w.qsa ? t.querySelectorAll(e) : void 0
                    } : function(e, t) {
                        var n, i = [],
                            o = 0,
                            r = t.getElementsByTagName(e);
                        if ("*" === e) {
                            for (; n = r[o++];) 1 === n.nodeType && i.push(n);
                            return i
                        }
                        return r
                    }, _.find.CLASS = w.getElementsByClassName && function(e, t) {
                        if (void 0 !== t.getElementsByClassName && D) return t.getElementsByClassName(e)
                    }, $ = [], M = [], (w.qsa = he.test(I.querySelectorAll)) && (o(function(e) {
                        O.appendChild(e).innerHTML = "<a id='" + F + "'></a><select id='" + F + "-\r\\' msallowcapture=''><option selected=''></option></select>", e.querySelectorAll("[msallowcapture^='']").length && M.push("[*^$]=" + ee + "*(?:''|\"\")"), e.querySelectorAll("[selected]").length || M.push("\\[" + ee + "*(?:value|" + Z + ")"), e.querySelectorAll("[id~=" + F + "-]").length || M.push("~="), e.querySelectorAll(":checked").length || M.push(":checked"), e.querySelectorAll("a#" + F + "+*").length || M.push(".#.+[+~]")
                    }), o(function(e) {
                        e.innerHTML = "<a href='' disabled='disabled'></a><select disabled='disabled'><option/></select>";
                        var t = I.createElement("input");
                        t.setAttribute("type", "hidden"), e.appendChild(t).setAttribute("name", "D"), e.querySelectorAll("[name=d]").length && M.push("name" + ee + "*[*^$|!~]?="), 2 !== e.querySelectorAll(":enabled").length && M.push(":enabled", ":disabled"), O.appendChild(e).disabled = !0, 2 !== e.querySelectorAll(":disabled").length && M.push(":enabled", ":disabled"), e.querySelectorAll("*,:x"), M.push(",.*:")
                    })), (w.matchesSelector = he.test(L = O.matches || O.webkitMatchesSelector || O.mozMatchesSelector || O.oMatchesSelector || O.msMatchesSelector)) && o(function(e) {
                        w.disconnectedMatch = L.call(e, "*"), L.call(e, "[s!='']:x"), $.push("!=", ie)
                    }), M = M.length && new RegExp(M.join("|")), $ = $.length && new RegExp($.join("|")), t = he.test(O.compareDocumentPosition), P = t || he.test(O.contains) ? function(e, t) {
                        var n = 9 === e.nodeType ? e.documentElement : e,
                            i = t && t.parentNode;
                        return e === i || !(!i || 1 !== i.nodeType || !(n.contains ? n.contains(i) : e.compareDocumentPosition && 16 & e.compareDocumentPosition(i)))
                    } : function(e, t) {
                        if (t)
                            for (; t = t.parentNode;)
                                if (t === e) return !0;
                        return !1
                    }, z = t ? function(e, t) {
                        if (e === t) return T = !0, 0;
                        var n = !e.compareDocumentPosition - !t.compareDocumentPosition;
                        return n || (n = (e.ownerDocument || e) === (t.ownerDocument || t) ? e.compareDocumentPosition(t) : 1, 1 & n || !w.sortDetached && t.compareDocumentPosition(e) === n ? e === I || e.ownerDocument === R && P(R, e) ? -1 : t === I || t.ownerDocument === R && P(R, t) ? 1 : S ? Q(S, e) - Q(S, t) : 0 : 4 & n ? -1 : 1)
                    } : function(e, t) {
                        if (e === t) return T = !0, 0;
                        var n, i = 0,
                            o = e.parentNode,
                            r = t.parentNode,
                            s = [e],
                            c = [t];
                        if (!o || !r) return e === I ? -1 : t === I ? 1 : o ? -1 : r ? 1 : S ? Q(S, e) - Q(S, t) : 0;
                        if (o === r) return a(e, t);
                        for (n = e; n = n.parentNode;) s.unshift(n);
                        for (n = t; n = n.parentNode;) c.unshift(n);
                        for (; s[i] === c[i];) i++;
                        return i ? a(s[i], c[i]) : s[i] === R ? -1 : c[i] === R ? 1 : 0
                    }, I) : I
                }, t.matches = function(e, n) {
                    return t(e, null, null, n)
                }, t.matchesSelector = function(e, n) {
                    if ((e.ownerDocument || e) !== I && A(e), n = n.replace(ce, "='$1']"), w.matchesSelector && D && !B[n + " "] && (!$ || !$.test(n)) && (!M || !M.test(n))) try {
                        var i = L.call(e, n);
                        if (i || w.disconnectedMatch || e.document && 11 !== e.document.nodeType) return i
                    } catch (e) {}
                    return t(n, I, null, [e]).length > 0
                }, t.contains = function(e, t) {
                    return (e.ownerDocument || e) !== I && A(e), P(e, t)
                }, t.attr = function(e, t) {
                    (e.ownerDocument || e) !== I && A(e);
                    var n = _.attrHandle[t.toLowerCase()],
                        i = n && W.call(_.attrHandle, t.toLowerCase()) ? n(e, t, !D) : void 0;
                    return void 0 !== i ? i : w.attributes || !D ? e.getAttribute(t) : (i = e.getAttributeNode(t)) && i.specified ? i.value : null
                }, t.escape = function(e) {
                    return (e + "").replace(be, we)
                }, t.error = function(e) {
                    throw new Error("Syntax error, unrecognized expression: " + e)
                }, t.uniqueSort = function(e) {
                    var t, n = [],
                        i = 0,
                        o = 0;
                    if (T = !w.detectDuplicates, S = !w.sortStable && e.slice(0), e.sort(z), T) {
                        for (; t = e[o++];) t === e[o] && (i = n.push(o));
                        for (; i--;) e.splice(n[i], 1)
                    }
                    return S = null, e
                }, x = t.getText = function(e) {
                    var t, n = "",
                        i = 0,
                        o = e.nodeType;
                    if (o) {
                        if (1 === o || 9 === o || 11 === o) {
                            if ("string" == typeof e.textContent) return e.textContent;
                            for (e = e.firstChild; e; e = e.nextSibling) n += x(e)
                        } else if (3 === o || 4 === o) return e.nodeValue
                    } else
                        for (; t = e[i++];) n += x(t);
                    return n
                }, _ = t.selectors = {
                    cacheLength: 50,
                    createPseudo: i,
                    match: de,
                    attrHandle: {},
                    find: {},
                    relative: {
                        ">": {
                            dir: "parentNode",
                            first: !0
                        },
                        " ": {
                            dir: "parentNode"
                        },
                        "+": {
                            dir: "previousSibling",
                            first: !0
                        },
                        "~": {
                            dir: "previousSibling"
                        }
                    },
                    preFilter: {
                        ATTR: function(e) {
                            return e[1] = e[1].replace(ge, ye), e[3] = (e[3] || e[4] || e[5] || "").replace(ge, ye), "~=" === e[2] && (e[3] = " " + e[3] + " "), e.slice(0, 4)
                        },
                        CHILD: function(e) {
                            return e[1] = e[1].toLowerCase(), "nth" === e[1].slice(0, 3) ? (e[3] || t.error(e[0]), e[4] = +(e[4] ? e[5] + (e[6] || 1) : 2 * ("even" === e[3] || "odd" === e[3])), e[5] = +(e[7] + e[8] || "odd" === e[3])) : e[3] && t.error(e[0]), e
                        },
                        PSEUDO: function(e) {
                            var t, n = !e[6] && e[2];
                            return de.CHILD.test(e[0]) ? null : (e[3] ? e[2] = e[4] || e[5] || "" : n && ue.test(n) && (t = j(n, !0)) && (t = n.indexOf(")", n.length - t) - n.length) && (e[0] = e[0].slice(0, t), e[2] = n.slice(0, t)), e.slice(0, 3))
                        }
                    },
                    filter: {
                        TAG: function(e) {
                            var t = e.replace(ge, ye).toLowerCase();
                            return "*" === e ? function() {
                                return !0
                            } : function(e) {
                                return e.nodeName && e.nodeName.toLowerCase() === t
                            }
                        },
                        CLASS: function(e) {
                            var t = H[e + " "];
                            return t || (t = new RegExp("(^|" + ee + ")" + e + "(" + ee + "|$)")) && H(e, function(e) {
                                return t.test("string" == typeof e.className && e.className || void 0 !== e.getAttribute && e.getAttribute("class") || "")
                            })
                        },
                        ATTR: function(e, n, i) {
                            return function(o) {
                                var r = t.attr(o, e);
                                return null == r ? "!=" === n : !n || (r += "", "=" === n ? r === i : "!=" === n ? r !== i : "^=" === n ? i && 0 === r.indexOf(i) : "*=" === n ? i && r.indexOf(i) > -1 : "$=" === n ? i && r.slice(-i.length) === i : "~=" === n ? (" " + r.replace(oe, " ") + " ").indexOf(i) > -1 : "|=" === n && (r === i || r.slice(0, i.length + 1) === i + "-"))
                            }
                        },
                        CHILD: function(e, t, n, i, o) {
                            var r = "nth" !== e.slice(0, 3),
                                a = "last" !== e.slice(-4),
                                s = "of-type" === t;
                            return 1 === i && 0 === o ? function(e) {
                                return !!e.parentNode
                            } : function(t, n, c) {
                                var u, l, d, f, p, h, m = r !== a ? "nextSibling" : "previousSibling",
                                    v = t.parentNode,
                                    g = s && t.nodeName.toLowerCase(),
                                    y = !c && !s,
                                    b = !1;
                                if (v) {
                                    if (r) {
                                        for (; m;) {
                                            for (f = t; f = f[m];)
                                                if (s ? f.nodeName.toLowerCase() === g : 1 === f.nodeType) return !1;
                                            h = m = "only" === e && !h && "nextSibling"
                                        }
                                        return !0
                                    }
                                    if (h = [a ? v.firstChild : v.lastChild], a && y) {
                                        for (f = v, d = f[F] || (f[F] = {}), l = d[f.uniqueID] || (d[f.uniqueID] = {}), u = l[e] || [], p = u[0] === q && u[1], b = p && u[2], f = p && v.childNodes[p]; f = ++p && f && f[m] || (b = p = 0) || h.pop();)
                                            if (1 === f.nodeType && ++b && f === t) {
                                                l[e] = [q, p, b];
                                                break
                                            }
                                    } else if (y && (f = t, d = f[F] || (f[F] = {}), l = d[f.uniqueID] || (d[f.uniqueID] = {}), u = l[e] || [], p = u[0] === q && u[1], b = p), !1 === b)
                                        for (;
                                            (f = ++p && f && f[m] || (b = p = 0) || h.pop()) && ((s ? f.nodeName.toLowerCase() !== g : 1 !== f.nodeType) || !++b || (y && (d = f[F] || (f[F] = {}), l = d[f.uniqueID] || (d[f.uniqueID] = {}), l[e] = [q, b]), f !== t)););
                                    return (b -= o) === i || b % i == 0 && b / i >= 0
                                }
                            }
                        },
                        PSEUDO: function(e, n) {
                            var o, r = _.pseudos[e] || _.setFilters[e.toLowerCase()] || t.error("unsupported pseudo: " + e);
                            return r[F] ? r(n) : r.length > 1 ? (o = [e, e, "", n], _.setFilters.hasOwnProperty(e.toLowerCase()) ? i(function(e, t) {
                                for (var i, o = r(e, n), a = o.length; a--;) i = Q(e, o[a]), e[i] = !(t[i] = o[a])
                            }) : function(e) {
                                return r(e, 0, o)
                            }) : r
                        }
                    },
                    pseudos: {
                        not: i(function(e) {
                            var t = [],
                                n = [],
                                o = C(e.replace(re, "$1"));
                            return o[F] ? i(function(e, t, n, i) {
                                for (var r, a = o(e, null, i, []), s = e.length; s--;)(r = a[s]) && (e[s] = !(t[s] = r))
                            }) : function(e, i, r) {
                                return t[0] = e, o(t, null, r, n), t[0] = null, !n.pop()
                            }
                        }),
                        has: i(function(e) {
                            return function(n) {
                                return t(e, n).length > 0
                            }
                        }),
                        contains: i(function(e) {
                            return e = e.replace(ge, ye),
                                function(t) {
                                    return (t.textContent || t.innerText || x(t)).indexOf(e) > -1
                                }
                        }),
                        lang: i(function(e) {
                            return le.test(e || "") || t.error("unsupported lang: " + e), e = e.replace(ge, ye).toLowerCase(),
                                function(t) {
                                    var n;
                                    do {
                                        if (n = D ? t.lang : t.getAttribute("xml:lang") || t.getAttribute("lang")) return (n = n.toLowerCase()) === e || 0 === n.indexOf(e + "-")
                                    } while ((t = t.parentNode) && 1 === t.nodeType);
                                    return !1
                                }
                        }),
                        target: function(t) {
                            var n = e.location && e.location.hash;
                            return n && n.slice(1) === t.id
                        },
                        root: function(e) {
                            return e === O
                        },
                        focus: function(e) {
                            return e === I.activeElement && (!I.hasFocus || I.hasFocus()) && !!(e.type || e.href || ~e.tabIndex)
                        },
                        enabled: s(!1),
                        disabled: s(!0),
                        checked: function(e) {
                            var t = e.nodeName.toLowerCase();
                            return "input" === t && !!e.checked || "option" === t && !!e.selected
                        },
                        selected: function(e) {
                            return e.parentNode && e.parentNode.selectedIndex, !0 === e.selected
                        },
                        empty: function(e) {
                            for (e = e.firstChild; e; e = e.nextSibling)
                                if (e.nodeType < 6) return !1;
                            return !0
                        },
                        parent: function(e) {
                            return !_.pseudos.empty(e)
                        },
                        header: function(e) {
                            return pe.test(e.nodeName)
                        },
                        input: function(e) {
                            return fe.test(e.nodeName)
                        },
                        button: function(e) {
                            var t = e.nodeName.toLowerCase();
                            return "input" === t && "button" === e.type || "button" === t
                        },
                        text: function(e) {
                            var t;
                            return "input" === e.nodeName.toLowerCase() && "text" === e.type && (null == (t = e.getAttribute("type")) || "text" === t.toLowerCase())
                        },
                        first: c(function() {
                            return [0]
                        }),
                        last: c(function(e, t) {
                            return [t - 1]
                        }),
                        eq: c(function(e, t, n) {
                            return [n < 0 ? n + t : n]
                        }),
                        even: c(function(e, t) {
                            for (var n = 0; n < t; n += 2) e.push(n);
                            return e
                        }),
                        odd: c(function(e, t) {
                            for (var n = 1; n < t; n += 2) e.push(n);
                            return e
                        }),
                        lt: c(function(e, t, n) {
                            for (var i = n < 0 ? n + t : n; --i >= 0;) e.push(i);
                            return e
                        }),
                        gt: c(function(e, t, n) {
                            for (var i = n < 0 ? n + t : n; ++i < t;) e.push(i);
                            return e
                        })
                    }
                }, _.pseudos.nth = _.pseudos.eq;
                for (b in {
                        radio: !0,
                        checkbox: !0,
                        file: !0,
                        password: !0,
                        image: !0
                    }) _.pseudos[b] = function(e) {
                    return function(t) {
                        return "input" === t.nodeName.toLowerCase() && t.type === e
                    }
                }(b);
                for (b in {
                        submit: !0,
                        reset: !0
                    }) _.pseudos[b] = function(e) {
                    return function(t) {
                        var n = t.nodeName.toLowerCase();
                        return ("input" === n || "button" === n) && t.type === e
                    }
                }(b);
                return l.prototype = _.filters = _.pseudos, _.setFilters = new l, j = t.tokenize = function(e, n) {
                    var i, o, r, a, s, c, u, l = V[e + " "];
                    if (l) return n ? 0 : l.slice(0);
                    for (s = e, c = [], u = _.preFilter; s;) {
                        i && !(o = ae.exec(s)) || (o && (s = s.slice(o[0].length) || s), c.push(r = [])), i = !1, (o = se.exec(s)) && (i = o.shift(), r.push({
                            value: i,
                            type: o[0].replace(re, " ")
                        }), s = s.slice(i.length));
                        for (a in _.filter) !(o = de[a].exec(s)) || u[a] && !(o = u[a](o)) || (i = o.shift(), r.push({
                            value: i,
                            type: a,
                            matches: o
                        }), s = s.slice(i.length));
                        if (!i) break
                    }
                    return n ? s.length : s ? t.error(e) : V(e, c).slice(0)
                }, C = t.compile = function(e, t) {
                    var n, i = [],
                        o = [],
                        r = B[e + " "];
                    if (!r) {
                        for (t || (t = j(e)), n = t.length; n--;) r = g(t[n]), r[F] ? i.push(r) : o.push(r);
                        r = B(e, y(o, i)), r.selector = e
                    }
                    return r
                }, E = t.select = function(e, t, n, i) {
                    var o, r, a, s, c, l = "function" == typeof e && e,
                        f = !i && j(e = l.selector || e);
                    if (n = n || [], 1 === f.length) {
                        if (r = f[0] = f[0].slice(0), r.length > 2 && "ID" === (a = r[0]).type && 9 === t.nodeType && D && _.relative[r[1].type]) {
                            if (!(t = (_.find.ID(a.matches[0].replace(ge, ye), t) || [])[0])) return n;
                            l && (t = t.parentNode), e = e.slice(r.shift().value.length)
                        }
                        for (o = de.needsContext.test(e) ? 0 : r.length; o-- && (a = r[o], !_.relative[s = a.type]);)
                            if ((c = _.find[s]) && (i = c(a.matches[0].replace(ge, ye), ve.test(r[0].type) && u(t.parentNode) || t))) {
                                if (r.splice(o, 1), !(e = i.length && d(r))) return X.apply(n, i), n;
                                break
                            }
                    }
                    return (l || C(e, f))(i, t, !D, n, !t || ve.test(e) && u(t.parentNode) || t), n
                }, w.sortStable = F.split("").sort(z).join("") === F, w.detectDuplicates = !!T, A(), w.sortDetached = o(function(e) {
                    return 1 & e.compareDocumentPosition(I.createElement("fieldset"))
                }), o(function(e) {
                    return e.innerHTML = "<a href='#'></a>", "#" === e.firstChild.getAttribute("href")
                }) || r("type|href|height|width", function(e, t, n) {
                    if (!n) return e.getAttribute(t, "type" === t.toLowerCase() ? 1 : 2)
                }), w.attributes && o(function(e) {
                    return e.innerHTML = "<input/>", e.firstChild.setAttribute("value", ""), "" === e.firstChild.getAttribute("value")
                }) || r("value", function(e, t, n) {
                    if (!n && "input" === e.nodeName.toLowerCase()) return e.defaultValue
                }), o(function(e) {
                    return null == e.getAttribute("disabled")
                }) || r(Z, function(e, t, n) {
                    var i;
                    if (!n) return !0 === e[t] ? t.toLowerCase() : (i = e.getAttributeNode(t)) && i.specified ? i.value : null
                }), t
            }(n);

        if (l(".anime-slide-block")[0])
            for (var n = l(".anime-slide-block").length, i = 0; i < n; i++) {
                var o = l(".anime-slide-block").eq(i).attr("id");
                ! function(t, n, i) {
                    var o = l("#" + t + ".anime-slide-block");
                    if (o.length) {
                        var r = o.data("json"),
                            n = n || r.btnWidth,
                            i = i || r.margin;
                        o.css({
                            width: r.width
                        }), o.find(".anime-slide-outer").css({
                            width: r.width
                        }), o.find(".anime-slide").css({
                            width: r.width
                        });
                        var a = o.find(".js-anime-slide").data("slide") || 4,
                            s = o.find(".anime-slide li.btn-anime").eq(0).outerWidth(),
                            c = o.find(".anime-slide li.btn-anime").length,
                            u = s + i,
                            d = u * (c + a);
                        o.find(".anime-slide").width(d);
                        var f = o.find(".btn-anime-slide-side.left"),
                            p = o.find(".btn-anime-slide-side.right");
                        c < a + 1 ? (f.hide(), p.hide()) : e || function() {
                            var e = setInterval(function() {
                                f.css({
                                    left: -1 * n,
                                    opacity: 0
                                }), p.css({
                                    right: -1 * n,
                                    opacity: 0
                                }), clearInterval(e)
                            }, 1500)
                        }(), f.find(".btn-inner").on("click", function(e) {
                            var t = {
                                direction: "left",
                                button: l(this)
                            };
                            h(t)
                        }), p.find(".btn-inner").on("click", function(e) {
                            var t = {
                                direction: "right",
                                button: l(this)
                            };
                            h(t)
                        }), e || (o.find(".anime-slide-outer").on("mouseover", function() {
                            f.css({
                                left: 0,
                                opacity: 1
                            }), p.css({
                                right: 0,
                                opacity: 1
                            })
                        }).on("mouseout", function() {
                            f.css({
                                left: -1 * n,
                                opacity: 0
                            }), p.css({
                                right: -1 * n,
                                opacity: 0
                            })
                        }), f.on("mouseover", function() {
                            f.css({
                                left: 0,
                                opacity: 1
                            }), p.css({
                                right: -1 * n,
                                opacity: 0
                            })
                        }).on("mouseout", function() {
                            p.css({
                                right: -1 * n,
                                opacity: 0
                            }), f.css({
                                left: -1 * n,
                                opacity: 0
                            })
                        }), p.on("mouseover", function() {
                            p.css({
                                right: 0,
                                opacity: 1
                            }), f.css({
                                left: -1 * n,
                                opacity: 0
                            })
                        }).on("mouseout", function() {
                            p.css({
                                right: -1 * n,
                                opacity: 0
                            }), f.css({
                                left: -1 * n,
                                opacity: 0
                            })
                        }));
                        var h = function(e) {
                            var t = e.direction,
                                n = e.button;
                            if (n.hide(), "right" == t) {
                                var i = [];
                                o.find(".anime-slide li.btn-anime").each(function() {
                                    i.push(l(this))
                                });
                                for (var r = 0; r < a; r++) i[r].clone(!0).insertAfter(o.find(".anime-slide li.btn-anime:last"));
                                o.find(".anime-slide").css("marginLeft", "0px"), o.find(".anime-slide").animate({
                                    marginLeft: -1 * u * a + "px"
                                }, {
                                    duration: 500,
                                    easing: "swing",
                                    complete: function() {
                                        for (var e = parseInt(o.find(".anime-slide").css("marginLeft").replace("px", "")), t = 0; t < a; t++) o.find(".anime-slide").css("marginLeft", e + u * a + "px"), o.find(".anime-slide li.btn-anime:first").remove();
                                        n.show()
                                    }
                                })
                            } else {
                                var i = [];
                                o.find(".anime-slide li.btn-anime").each(function() {
                                    i.push(l(this))
                                }), i.reverse();
                                for (var r = 0; r < a; r++) i[r].clone(!0).insertBefore(o.find(".anime-slide li.btn-anime:first"));
                                var s = -1 * u * a + "px";
                                o.find(".anime-slide").css("marginLeft", s), o.find(".anime-slide").animate({
                                    marginLeft: "0px"
                                }, {
                                    duration: 500,
                                    easing: "swing",
                                    complete: function() {
                                        for (var e = 0; e < a; e++) o.find(".anime-slide li.btn-anime:last").remove();
                                        n.show()
                                    }
                                })
                            }
                        }
                    }
                }(o)
            }
        l(".js-daisuki-dragonball-super")[0] && l(".js-daisuki-dragonball-super").on("click", function() {
            var e = l(this).data("json");
            s.default.actionLog("daisuki_dragonball", {
                category: e.category,
                id: e.id,
                title: e.title
            }), window.open(e.url, "_blank")
        }), l(".js-shop-selecter")[0] && (l(".js-shop-selecter").on("mouseenter", function() {
            l(".js-shop-selecter-dialog").fadeIn()
        }), l(".js-shop-selecter-dialog").on("mouseenter", function() {
            l(this).show()
        }).on("mouseleave", function() {
            l(this).fadeOut()
        }))
    }